@echo off
cd /d "%~dp0"
title Lab Logger (with window, for troubleshooting)
python lab_logger.py
pause
