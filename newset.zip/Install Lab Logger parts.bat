@echo off
rem Installs (or repairs) the parts Lab Logger needs, into the same Python the launcher uses.
cd /d "%~dp0"
title Install Lab Logger parts
echo.
echo  Installing the parts Lab Logger needs...
echo  ------------------------------------------------------------

where python >nul 2>nul
if errorlevel 1 (
  echo  Python isn't installed on this laptop, or wasn't added to PATH.
  echo  Reinstall Python from python.org and tick "Add python.exe to PATH".
  goto :end
)

python -m pip --version >nul 2>nul
if errorlevel 1 python -m ensurepip --upgrade >nul 2>nul

rem 1) From the internet
python -m pip install --upgrade pyserial openpyxl xlrd
python -c "import serial, openpyxl, xlrd" >nul 2>nul
if not errorlevel 1 goto :ok

rem 2) No internet: from a "wheels" folder next to this file (copied on a flash drive)
if exist "%~dp0wheels" (
  echo.
  echo  No internet, trying the wheels folder instead...
  python -m pip install --no-index --find-links="%~dp0wheels" pyserial openpyxl xlrd
  python -c "import serial, openpyxl, xlrd" >nul 2>nul
  if not errorlevel 1 goto :ok
)

echo.
echo  ------------------------------------------------------------
echo  The install didn't work.
echo  If this laptop has no internet: on a computer that does, download the
echo  pyserial, openpyxl, et_xmlfile and xlrd files from pypi.org, put them in a folder
echo  called "wheels" next to this file, then run this file again.
goto :end

:ok
echo.
echo  ------------------------------------------------------------
echo  Done. Everything Lab Logger needs is installed.
echo  You can now double-click Lab Logger.

:end
echo.
pause
