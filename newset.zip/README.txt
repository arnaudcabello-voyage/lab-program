LAB LOGGER - FILES
==================

Put everything in this folder into C:\LabLogger (replace the old files).

FILES
  lab_logger.py ................ the program
  lab_logger_config.json ....... settings: ports, folders, rules (see below)
  requirements.txt ............. list of parts the program needs
  Install Lab Logger parts.bat . run once on a new laptop (and after updates)
  Lab Logger.bat ............... starts Lab Logger and opens the dashboard
                                 (make the desktop shortcut from this one)
  Stop Lab Logger.bat .......... stops it (do this before replacing files)
  Lab Logger with window (troubleshooting).bat
                                 starts it with a window that shows messages
  demo_dashboard.bat ........... the dashboard with simulated instruments
                                 (saves nothing to the real data)

NOT IN THIS SET (made on the laptop, never replace or delete these)
  data\ ........................ all results, Excel workbooks, daily backups
  skala_token.txt .............. SKALA sign-in token (secret, this laptop only)
  lab_logger.log ............... the logger's diary, useful for fault-finding

UPDATING
  1. Double-click Stop Lab Logger.bat
  2. Copy the new files into C:\LabLogger, replacing the old ones
  3. Double-click Install Lab Logger parts.bat (wait for "Done")
  4. Double-click Lab Logger

SETTINGS (lab_logger_config.json)
  Ports: MB90 = COM3, pH meter = COM6. If they change, fix them on the
  dashboard's Support page (bottom of the main page); no file editing needed.
  Everything saves under C:/LabLogger/data.
  Colorimeter exports go in C:/LabLogger/data/Colorimeter Exports
  (.xls, .xlsx and .csv are all fine).
  Optional: "support_contact" (who operators should call), "support_pin"
  (a PIN for changing ports), "lot_rules" (lot format, operator name list,
  how long a lot stays active), "upload" (cloud folder).

The old start_logger.bat is replaced by "Lab Logger with window
(troubleshooting).bat" and can be deleted.
