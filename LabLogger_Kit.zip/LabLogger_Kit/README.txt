LAB LOGGER KIT
==============

WHAT'S IN THIS FOLDER

  README.txt                  this file

  Guide\
    Lab_Instrument_Connection_Guide.pdf
                              Step-by-step USB connection and testing guide.
                              Start here.

  Manuals\
    OHAUS_MB90_Moisture_Analyzer_Manual.pdf
    OHAUS_pH_Meter_a-AB33_a-AB41_Manual.pdf
    Linshang_LS177C_Coffee_Colorimeter_Manual.pdf
                              The manufacturers' manuals. (The colorimeter
                              manual was originally named
                              "Lingshan_Spectrophotometer_User_Manual.pdf".)

  LabLogger_Backup\
    lab_logger.py, requirements.txt, start_logger.bat
                              Spare copy of the logger. Your working copy is
                              C:\LabLogger. Only copy these over if a file
                              there gets deleted or damaged. Your
                              lab_logger_config.json is NOT in here, so
                              don't overwrite C:\LabLogger's copy.

  Troubleshooting\
    troubleshoot.bat          Double-click for a menu of the tools below.
    1_check_setup.py          Checks Python, packages, the config file,
                              folders and every instrument port. Tells you
                              what to fix. RUN THIS FIRST when stuck.
    2_find_ports.py           Lists serial ports, then watches: plug or
                              unplug an instrument and it names the port.
    3_test_port.py            Menu to test one port: listen while you press
                              Print, send query commands (pH: PV, PSN, LP 1;
                              MB90: V, DAT, TIM), or auto-find the right
                              baud rate when text is garbled.
    4_capture_sample.py       Records everything a port sends into
                              Troubleshooting\captures\ (text + hex).
    5_test_parser.py          Runs a capture through the logger's parser and
                              shows which CSV columns it would fill.

WHEN YOU GET STUCK

  1. Close the logger first (type  quit  in its window). Only one program
     can use a port at a time; the tools can't reach a port the logger is
     holding.
  2. Double-click Troubleshooting\troubleshoot.bat and choose 1.
  3. Instrument not showing up?     Choose 2, then unplug and replug it.
  4. Port found but no data?        Choose 3, then "Listen", press Print.
  5. Garbled symbols?               Choose 3, then "Find the right baud rate".
  6. Data arrives, columns empty?   Choose 4 to capture, then 5 to check.
                                    Paste the capture file into the Claude
                                    chat to get the parser adjusted.

KEY INSTRUMENT SETTINGS

  MB90:     Setup > Device settings > Peripheral settings > Device Port = COM4
            (COM4 = the MB90's USB connector; not the laptop's port number)
            Print settings > Print measurement result automatically = ON
            9600 baud, 8 data bits, no parity, 1 stop bit

  pH meter: Menu > Settings > RS232 > Export to = PC
            9600 baud, 8 None, 1 stop bit, handshake None
            Tap the printer icon after each reading to send it.

  LS177C:   No port needed. Export Excel (.xlsx) from the Linshang software
            into C:\LabLogger\data\Colorimeter Exports

The tools need Python and pyserial, already installed if the logger runs.
