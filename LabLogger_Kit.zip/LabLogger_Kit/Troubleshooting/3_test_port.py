#!/usr/bin/env python3
"""
3_test_port.py - Test one instrument's serial connection.

Run with no arguments for a menu, or:
  python 3_test_port.py COM5                 menu for COM5
  python 3_test_port.py COM5 --listen        show incoming data (press Print on the instrument)
  python 3_test_port.py COM5 --ask ph        send the pH meter's query commands
  python 3_test_port.py COM5 --ask mb90      send the MB90's query commands
  python 3_test_port.py COM5 --find-baud     try every baud rate to fix garbled text
  python 3_test_port.py COM5 --send "PV"     send any command

Close the logger first: only one program can use a port at a time.
"""
import argparse
import sys
import time

try:
    import serial
    import serial.tools.list_ports as lp
except ImportError:
    print("pyserial is not installed. Run:  pip install pyserial")
    sys.exit(1)

BAUDS = [9600, 19200, 38400, 4800, 2400, 1200, 57600, 115200]
SETTINGS = [("8N1", 8, "N", 1), ("7E1", 7, "E", 1), ("7O1", 7, "O", 1), ("7N1", 7, "N", 1)]

# Commands each instrument answers (from their manuals).
QUERIES = {
    "ph": [("PV", "software version"), ("PSN", "serial number"),
           ("LP 1", "last measurement result"), ("LP 0", "last calibration result")],
    "mb90": [("V", "software version"), ("DAT", "current date"), ("TIM", "current time")],
}


def printable_ratio(data):
    if not data:
        return 0.0
    good = sum(1 for b in data if 32 <= b < 127 or b in (9, 10, 13) or b in (0xB0, 0xB5))
    return good / len(data)


def show(data):
    text = data.decode("latin-1", errors="replace")
    sys.stdout.write(text)
    sys.stdout.flush()


def hexdump(data, width=16):
    for i in range(0, len(data), width):
        chunk = data[i:i + width]
        hx = " ".join(f"{b:02X}" for b in chunk)
        tx = "".join(chr(b) if 32 <= b < 127 else "." for b in chunk)
        print(f"   {hx:<{width * 3}} {tx}")


def open_port(port, baud=9600, bits=8, parity="N", stop=1):
    par = {"N": serial.PARITY_NONE, "E": serial.PARITY_EVEN, "O": serial.PARITY_ODD}[parity]
    try:
        return serial.Serial(port, baud, bytesize=bits, parity=par, stopbits=stop, timeout=0.3)
    except serial.SerialException as e:
        msg = str(e)
        print(f"\n  Could not open {port}: {msg}")
        if "denied" in msg.lower() or "busy" in msg.lower():
            print("  -> The port is in use. Close the logger (type quit) and any other")
            print("     test windows, then try again.")
        elif "FileNotFound" in msg or "could not open port" in msg.lower():
            print("  -> That port doesn't exist. Run 2_find_ports.py to see the right one.")
        return None


def verdict(data):
    if not data:
        return "NOTHING RECEIVED"
    r = printable_ratio(data)
    if r > 0.9:
        return "LOOKS GOOD (readable text)"
    if r > 0.6:
        return "PARTLY READABLE (settings may be slightly off)"
    return "GARBLED (baud rate / parity mismatch)"


def listen(port, baud, seconds=None, hexmode=False):
    s = open_port(port, baud)
    if not s:
        return
    print(f"\n  Listening on {port} at {baud} baud.")
    print("  Now press PRINT on the instrument (pH meter: tap the printer icon).")
    print("  Ctrl+C to stop.\n" + "-" * 60)
    got = bytearray()
    start = time.time()
    try:
        while seconds is None or time.time() - start < seconds:
            d = s.read(512)
            if d:
                got += d
                if hexmode:
                    hexdump(d)
                else:
                    show(d)
    except KeyboardInterrupt:
        pass
    s.close()
    print("\n" + "-" * 60)
    print(f"  Received {len(got)} bytes. Verdict: {verdict(bytes(got))}")
    if not got:
        print("  Nothing arrived. Check:")
        print("   - MB90: Setup > Device settings > Peripheral > Device Port = COM4 (for USB)")
        print("   - pH meter: Settings > RS232 > Export to = PC")
        print("   - Right port? Run 2_find_ports.py and unplug/replug to confirm.")
        print("   - Try a different USB cable (some cables only charge).")
    elif printable_ratio(bytes(got)) < 0.9:
        print("  Try the 'find baud rate' option to find the matching setting.")


def send(port, baud, cmd, wait=2.0, quiet=False):
    s = open_port(port, baud)
    if not s:
        return b""
    s.reset_input_buffer()
    s.write((cmd + "\r\n").encode("ascii"))
    s.flush()
    got = bytearray()
    end = time.time() + wait
    while time.time() < end:
        d = s.read(512)
        if d:
            got += d
            end = max(end, time.time() + 0.5)
    s.close()
    if not quiet:
        print(f"\n  Sent: {cmd!r}")
        if got:
            print("  Reply:")
            for line in got.decode("latin-1", errors="replace").splitlines():
                print(f"    {line}")
            if b"ES" in got and len(got) < 8:
                print("  ('ES' = the instrument didn't recognize that command)")
        else:
            print("  No reply.")
    return bytes(got)


def ask(port, baud, device):
    print(f"\n  Asking the {device.upper()} a few questions on {port} at {baud} baud...")
    answered = 0
    for cmd, what in QUERIES[device]:
        print(f"\n  --- {what} ---")
        reply = send(port, baud, cmd)
        if reply and reply.strip() != b"ES":
            answered += 1
    print("\n" + "-" * 60)
    if answered:
        print(f"  {answered}/{len(QUERIES[device])} commands answered. The connection works both ways.")
    else:
        print("  No answers. The instrument may only send when Print is pressed;")
        print("  use the 'listen' option and press Print instead. If that also shows")
        print("  nothing, check the cable, port and export settings.")


def find_baud(port, device=None):
    print(f"\n  Trying every common setting on {port}.")
    if device:
        print(f"  Sending a {device.upper()} query at each setting...")
    else:
        print("  Press PRINT on the instrument once at each prompt.")
    results = []
    for baud in BAUDS:
        for name, bits, par, stop in SETTINGS:
            s = open_port(port, baud, bits, par, stop)
            if not s:
                return
            s.reset_input_buffer()
            if device:
                s.write((QUERIES[device][0][0] + "\r\n").encode())
                wait = 1.5
            else:
                print(f"   {baud} {name}: press Print now...", end="", flush=True)
                wait = 5.0
            got = bytearray()
            end = time.time() + wait
            while time.time() < end:
                d = s.read(256)
                if d:
                    got += d
            s.close()
            r = printable_ratio(bytes(got))
            results.append((r, len(got), baud, name, bytes(got)))
            label = f"{r * 100:3.0f}% readable, {len(got)} bytes" if got else "nothing"
            print(f"   {baud:>6} {name}: {label}" if device else f" {label}")
            if got and r > 0.95 and len(got) > 5:
                break
        if results and results[-1][0] > 0.95 and results[-1][1] > 5:
            break
    best = max(results, key=lambda x: (x[0], x[1]))
    print("\n" + "-" * 60)
    if best[1] == 0:
        print("  Nothing received at any setting. This is a connection problem, not a")
        print("  baud problem: check the cable, the port, and the instrument's export setting.")
    else:
        print(f"  Best match: {best[2]} baud, {best[3]}  ({best[0] * 100:.0f}% readable)")
        print(f"  Sample: {best[4][:80].decode('latin-1', errors='replace')!r}")
        print(f"  Set the instrument AND lab_logger_config.json to baudrate {best[2]},")
        b = {"8N1": (8, "N"), "7E1": (7, "E"), "7O1": (7, "O"), "7N1": (7, "N")}[best[3]]
        print(f"  bytesize {b[0]}, parity \"{b[1]}\", stopbits 1.")


def pick_port():
    ports = sorted(lp.comports(), key=lambda p: p.device)
    if not ports:
        print("No serial ports found. Plug in the instrument and run 2_find_ports.py.")
        return None
    print("\nSerial ports:")
    for i, p in enumerate(ports, 1):
        print(f"  {i}. {p.device:20s} {p.description}")
    while True:
        c = input("\nChoose a port number (or type the name, e.g. COM5): ").strip()
        if c.isdigit() and 1 <= int(c) <= len(ports):
            return ports[int(c) - 1].device
        if c:
            return c


def menu(port, baud):
    while True:
        print("\n" + "=" * 60)
        print(f" TESTING {port} at {baud} baud")
        print("=" * 60)
        print("  1. Listen (then press Print on the instrument)")
        print("  2. Listen and show HEX bytes (for garbled data)")
        print("  3. Ask the pH meter questions (PV, PSN, LP 1, LP 0)")
        print("  4. Ask the MB90 questions (V, DAT, TIM)")
        print("  5. Find the right baud rate (fixes garbled text)")
        print("  6. Send my own command")
        print("  7. Change baud rate")
        print("  8. Choose a different port")
        print("  0. Quit")
        c = input("\nChoice: ").strip()
        if c == "1":
            listen(port, baud)
        elif c == "2":
            listen(port, baud, hexmode=True)
        elif c == "3":
            ask(port, baud, "ph")
        elif c == "4":
            ask(port, baud, "mb90")
        elif c == "5":
            d = input("  Which instrument? [p]H meter / [m]B90 / [n]either - I'll press Print: ").strip().lower()
            find_baud(port, {"p": "ph", "m": "mb90"}.get(d[:1]))
        elif c == "6":
            cmd = input("  Command to send: ").strip()
            if cmd:
                send(port, baud, cmd)
        elif c == "7":
            b = input(f"  Baud rate {BAUDS}: ").strip()
            if b.isdigit():
                baud = int(b)
        elif c == "8":
            port = pick_port() or port
        elif c in ("0", "q", "quit"):
            return


def main():
    ap = argparse.ArgumentParser(description="Test an instrument serial port")
    ap.add_argument("port", nargs="?")
    ap.add_argument("--baud", type=int, default=9600)
    ap.add_argument("--listen", action="store_true")
    ap.add_argument("--hex", action="store_true")
    ap.add_argument("--ask", choices=["ph", "mb90"])
    ap.add_argument("--find-baud", action="store_true")
    ap.add_argument("--device", choices=["ph", "mb90"], help="with --find-baud: send queries")
    ap.add_argument("--send")
    ap.add_argument("--seconds", type=float)
    a = ap.parse_args()

    port = a.port or pick_port()
    if not port:
        return
    if a.listen or a.hex:
        listen(port, a.baud, a.seconds, a.hex)
    elif a.ask:
        ask(port, a.baud, a.ask)
    elif a.find_baud:
        find_baud(port, a.device)
    elif a.send:
        send(port, a.baud, a.send)
    else:
        menu(port, a.baud)


if __name__ == "__main__":
    try:
        main()
    except KeyboardInterrupt:
        print("\nStopped.")
