@echo off
cd /d "%~dp0"
title Lab Logger Troubleshooting
:menu
cls
echo ============================================================
echo   LAB LOGGER TROUBLESHOOTING
echo ============================================================
echo.
echo   1. Check my whole setup (Python, packages, config, ports)
echo   2. Find ports / see which port an instrument is on
echo   3. Test a port (listen, ask questions, fix garbled text)
echo   4. Capture what an instrument sends into a file
echo   5. See how the logger reads a captured printout
echo   0. Exit
echo.
set /p choice=Choose 0-5 and press Enter: 
if "%choice%"=="1" python 1_check_setup.py & pause & goto menu
if "%choice%"=="2" python 2_find_ports.py & goto menu
if "%choice%"=="3" python 3_test_port.py & pause & goto menu
if "%choice%"=="4" python 4_capture_sample.py & goto menu
if "%choice%"=="5" python 5_test_parser.py & goto menu
if "%choice%"=="0" exit /b
goto menu
