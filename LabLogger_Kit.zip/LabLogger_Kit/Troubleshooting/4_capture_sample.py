#!/usr/bin/env python3
"""
4_capture_sample.py - Record exactly what an instrument sends into a file.

Use this when a value shows up in raw_text but not in its own CSV column, or
when you want someone to check the output format. It saves two files in this
folder: a readable text copy and a byte-by-byte hex copy.

Run:   python 4_capture_sample.py COM6            (Ctrl+C when done)
       python 4_capture_sample.py COM6 --baud 19200
"""
import argparse
import datetime as dt
import sys
import time
from pathlib import Path

try:
    import serial
    import serial.tools.list_ports as lp
except ImportError:
    print("pyserial is not installed. Run:  pip install pyserial")
    sys.exit(1)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("port", nargs="?")
    ap.add_argument("--baud", type=int, default=9600)
    a = ap.parse_args()

    port = a.port
    if not port:
        ports = sorted(lp.comports(), key=lambda p: p.device)
        for i, p in enumerate(ports, 1):
            print(f"  {i}. {p.device:20s} {p.description}")
        c = input("Choose a port number: ").strip()
        port = ports[int(c) - 1].device if c.isdigit() and ports else c

    label = input("What instrument is this (e.g. pH, MB90)? ").strip() or "instrument"
    stamp = dt.datetime.now().strftime("%Y%m%d-%H%M%S")
    out_dir = Path(__file__).resolve().parent / "captures"
    out_dir.mkdir(exist_ok=True)
    txt_path = out_dir / f"capture_{label}_{port.replace('/', '_')}_{stamp}.txt"
    hex_path = txt_path.with_suffix(".hex.txt")

    try:
        s = serial.Serial(port, a.baud, timeout=0.3)
    except serial.SerialException as e:
        print(f"Could not open {port}: {e}")
        print("Close the logger and any other test windows, and check the port name.")
        return

    print(f"\nRecording {port} at {a.baud} baud into:\n  {txt_path}")
    print("Now press Print on the instrument (do it 2-3 times with different")
    print("readings if you can). Press Ctrl+C when finished.\n" + "-" * 60)
    data = bytearray()
    try:
        while True:
            d = s.read(512)
            if d:
                data += d
                sys.stdout.write(d.decode("latin-1", errors="replace"))
                sys.stdout.flush()
            time.sleep(0.01)
    except KeyboardInterrupt:
        pass
    s.close()

    with open(txt_path, "w", encoding="utf-8") as f:
        f.write(f"# Instrument: {label}\n# Port: {port}  Baud: {a.baud}\n# Captured: {stamp}\n\n")
        f.write(data.decode("latin-1", errors="replace"))
    with open(hex_path, "w", encoding="utf-8") as f:
        for i in range(0, len(data), 16):
            chunk = data[i:i + 16]
            f.write(f"{i:06X}  {' '.join(f'{b:02X}' for b in chunk):<48} "
                    f"{''.join(chr(b) if 32 <= b < 127 else '.' for b in chunk)}\n")
    print("\n" + "-" * 60)
    print(f"Saved {len(data)} bytes.")
    print(f"  Text: {txt_path}")
    print(f"  Hex:  {hex_path}")
    if not data:
        print("Nothing was received. Run 3_test_port.py to troubleshoot the connection.")
    else:
        print("Paste the text file into the Claude chat to have the parser checked.")


if __name__ == "__main__":
    main()
    if sys.platform.startswith("win") and sys.stdin.isatty():
        input("\nPress Enter to close...")
