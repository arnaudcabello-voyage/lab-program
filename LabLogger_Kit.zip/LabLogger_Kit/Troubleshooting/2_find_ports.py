#!/usr/bin/env python3
"""
2_find_ports.py - Shows every serial port and tells you which one is which.

It lists the ports that exist now, then keeps watching. Plug an instrument in
(or unplug it) and it prints exactly which port appeared or disappeared.

Run:   python 2_find_ports.py          list + watch (Ctrl+C to stop)
       python 2_find_ports.py --once   list only
"""
import sys
import time

try:
    import serial.tools.list_ports as lp
except ImportError:
    print("pyserial is not installed. Run:  pip install pyserial")
    if sys.platform.startswith("win"):
        input("Press Enter to close...")
    sys.exit(1)

# Common USB-to-serial chips, by USB vendor ID, to help identify adapters.
KNOWN_VENDORS = {
    0x0403: "FTDI USB-serial chip",
    0x067B: "Prolific USB-serial chip (common in RS232 adapters)",
    0x1A86: "CH340 USB-serial chip",
    0x10C4: "Silicon Labs CP210x USB-serial chip",
    0x04D8: "Microchip USB device",
    0x0483: "STMicroelectronics USB device",
    0x2341: "Arduino (not a lab instrument)",
}


def describe(p):
    bits = [p.description or "(no description)"]
    if p.vid is not None:
        bits.append(f"VID:PID {p.vid:04X}:{p.pid:04X}")
        if p.vid in KNOWN_VENDORS:
            bits.append(KNOWN_VENDORS[p.vid])
    if p.manufacturer:
        bits.append(f"maker: {p.manufacturer}")
    if p.serial_number:
        bits.append(f"serial: {p.serial_number}")
    return " | ".join(bits)


def snapshot():
    return {p.device: p for p in lp.comports()}


def print_list(ports):
    if not ports:
        print("  No serial ports found.")
        print("  - Is the instrument switched on and plugged in with a DATA cable?")
        print("  - Windows: check Device Manager > Ports (COM & LPT) and 'Other devices'")
        print("    (a yellow warning icon means a driver is needed, e.g. the OHAUS USB driver).")
        return
    for dev in sorted(ports):
        print(f"  {dev:24s} {describe(ports[dev])}")


def main():
    once = "--once" in sys.argv
    print("=" * 70)
    print(" SERIAL PORTS ON THIS COMPUTER")
    print("=" * 70)
    before = snapshot()
    print_list(before)
    print()
    print(" Tip: 'Bluetooth' ports are not your instruments; ignore them.")
    print(" The MB90 and pH meter usually appear as 'USB Serial Device (COMx)'.")
    print(" The LS177C colorimeter talks to the Linshang software and may not")
    print(" show up here at all; that is normal.")
    if once:
        return

    print()
    print("=" * 70)
    print(" WATCHING - plug in or unplug ONE instrument now. Ctrl+C to stop.")
    print("=" * 70)
    try:
        while True:
            time.sleep(1)
            now = snapshot()
            for dev in sorted(set(now) - set(before)):
                print(f"\n  >>> NEW PORT:  {dev}")
                print(f"      {describe(now[dev])}")
                print(f"      Put \"port\": \"{dev}\" in lab_logger_config.json for this instrument,")
                print(f"      then test it with:  python 3_test_port.py {dev}")
            for dev in sorted(set(before) - set(now)):
                print(f"\n  <<< REMOVED:   {dev}  (that was the device you just unplugged)")
            before = now
    except KeyboardInterrupt:
        print("\nStopped.")


if __name__ == "__main__":
    main()
    if sys.platform.startswith("win") and sys.stdin.isatty() and "--once" not in sys.argv:
        input("\nPress Enter to close...")
