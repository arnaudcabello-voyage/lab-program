#!/usr/bin/env python3
"""
1_check_setup.py - Checks everything the lab logger needs and says what to fix.

Checks: Python version, required packages, the LabLogger folder, the config
file (including JSON typos), the data folders, the colorimeter export folder,
and each instrument's serial port (present? free to open?).

Run:   python 1_check_setup.py
       python 1_check_setup.py "D:/Some Other/LabLogger"   (if not in C:\\LabLogger)
"""
import json
import os
import sys
from pathlib import Path

RESULTS = []  # (status, message, fix)


def ok(msg):
    RESULTS.append(("PASS", msg, ""))
    print(f"  [PASS] {msg}")


def warn(msg, fix=""):
    RESULTS.append(("WARN", msg, fix))
    print(f"  [WARN] {msg}")
    if fix:
        print(f"         -> {fix}")


def fail(msg, fix=""):
    RESULTS.append(("FAIL", msg, fix))
    print(f"  [FAIL] {msg}")
    if fix:
        print(f"         -> {fix}")


def norm(port):
    return port.upper() if sys.platform.startswith("win") else port


def expand(p):
    return Path(os.path.expandvars(os.path.expanduser(p)))


def find_lablogger(arg):
    here = Path(__file__).resolve().parent
    candidates = []
    if arg:
        candidates.append(Path(arg))
    candidates += [here, here.parent, here.parent / "LabLogger", Path("C:/LabLogger"),
                   Path.home() / "LabLogger", here.parent / "LabLogger_Backup"]
    for c in candidates:
        if (c / "lab_logger.py").exists():
            return c
    return None


def main():
    arg = sys.argv[1] if len(sys.argv) > 1 else None
    print("=" * 64)
    print(" LAB LOGGER SETUP CHECK")
    print("=" * 64)

    # 1. Python ---------------------------------------------------------
    print("\n1. Python")
    v = sys.version_info
    if v >= (3, 8):
        ok(f"Python {v.major}.{v.minor}.{v.micro} at {sys.executable}")
    else:
        fail(f"Python {v.major}.{v.minor} is too old", "Install Python 3.10 or newer from python.org")

    # 2. Packages --------------------------------------------------------
    print("\n2. Packages")
    serial = None
    try:
        import serial as _serial
        import serial.tools.list_ports  # noqa: F401
        serial = _serial
        ok(f"pyserial {getattr(serial, '__version__', '?')} installed")
    except ImportError:
        fail("pyserial is not installed",
             "In the LabLogger folder run:  pip install -r requirements.txt")
    try:
        import openpyxl
        ok(f"openpyxl {openpyxl.__version__} installed (needed for colorimeter .xlsx files)")
    except ImportError:
        fail("openpyxl is not installed",
             "In the LabLogger folder run:  pip install -r requirements.txt")

    # 3. LabLogger folder ------------------------------------------------
    print("\n3. LabLogger folder")
    folder = find_lablogger(arg)
    if not folder:
        fail("Could not find lab_logger.py",
             "Put it in C:\\LabLogger, or run: python 1_check_setup.py \"<path to folder>\"")
        return summary()
    ok(f"Found lab_logger.py in {folder}")
    if folder.name == "LabLogger_Backup":
        warn("Using the BACKUP copy in the kit, not your working C:\\LabLogger",
             "If you have a working folder elsewhere, pass its path as an argument")
    for f in ("requirements.txt", "start_logger.bat"):
        if (folder / f).exists():
            ok(f"{f} present")
        else:
            warn(f"{f} missing", "Copy it from the kit's LabLogger_Backup folder")

    # 4. Config ----------------------------------------------------------
    print("\n4. Config file (lab_logger_config.json)")
    cfg_path = folder / "lab_logger_config.json"
    if not cfg_path.exists():
        fail("lab_logger_config.json does not exist yet",
             "Run  python lab_logger.py  once in the LabLogger folder; it creates the file")
        return summary()
    text = cfg_path.read_text(encoding="utf-8", errors="replace")
    try:
        cfg = json.loads(text)
        ok("Config is valid JSON")
    except json.JSONDecodeError as e:
        line = text.splitlines()[e.lineno - 1] if e.lineno - 1 < len(text.splitlines()) else ""
        fail(f"Config has a typo at line {e.lineno}, column {e.colno}: {e.msg}",
             f"Look at this line:  {line.strip()}")
        if "\\" in text and "Invalid \\escape" in e.msg:
            print("         -> Windows paths need forward slashes: C:/LabLogger/data")
        return summary()

    # 5. Folders ---------------------------------------------------------
    print("\n5. Data folders")
    out = cfg.get("output_folder", "")
    if not out:
        fail("output_folder is empty in the config")
    else:
        out_p = expand(out)
        try:
            out_p.mkdir(parents=True, exist_ok=True)
            test = out_p / ".write_test"
            test.write_text("ok")
            test.unlink()
            ok(f"output_folder is writable: {out_p}")
        except Exception as e:
            fail(f"Cannot write to output_folder {out_p}: {e}",
                 "Check the path spelling, or choose a folder you have permission to write")
        for sub in ("MB90", "pH_meter", "LS177C"):
            p = out_p / sub
            if p.exists():
                csvs = sorted(p.glob("*.csv"))
                if csvs:
                    newest = csvs[-1]
                    rows = max(0, sum(1 for _ in open(newest, encoding="utf-8-sig", errors="replace")) - 1)
                    ok(f"{sub}: newest file {newest.name} has {rows} row(s)")
                else:
                    warn(f"{sub}: folder exists but no data yet", "Take a measurement with the logger running")

    # 6. Instruments -----------------------------------------------------
    print("\n6. Instruments")
    available = {}
    if serial:
        for p in serial.tools.list_ports.comports():
            available[norm(p.device)] = p.description
        if available:
            print("  Serial ports this computer can see right now:")
            for dev, desc in available.items():
                print(f"     {dev:22s} {desc}")
        else:
            warn("No serial ports visible at all",
                 "Plug in and switch on the MB90 / pH meter; try another USB cable")

    for inst in cfg.get("instruments", []):
        name = inst.get("name", "?")
        if not inst.get("enabled", True):
            warn(f"{name}: disabled in config (enabled = false)")
            continue
        itype = inst.get("type")
        if itype in ("mb90", "ph"):
            port = str(inst.get("port", ""))
            baud = inst.get("baudrate", 9600)
            if not serial:
                continue
            if norm(port) not in available:
                fail(f"{name}: port {port} is not connected right now",
                     "Plug it in, then run 2_find_ports.py to see its real port and fix the config")
                continue
            try:
                s = serial.Serial(port, baud, timeout=0.2)
                s.close()
                ok(f"{name}: {port} found and free to open at {baud} baud ({available[norm(port)]})")
            except serial.SerialException as e:
                msg = str(e)
                if "Access is denied" in msg or "busy" in msg.lower() or "PermissionError" in msg:
                    warn(f"{name}: {port} exists but is in use by another program",
                         "Normal if the logger is running. Otherwise close other windows using it")
                else:
                    fail(f"{name}: cannot open {port}: {msg}")
            if itype == "ph":
                print("         Reminder: pH meter Settings -> RS232 -> Export to must be 'PC'")
            else:
                print("         Reminder: MB90 Peripheral settings -> Device Port COM4 (USB); auto-print ON")
        elif itype == "colorimeter_folder":
            wf = expand(inst.get("watch_folder", ""))
            if not inst.get("watch_folder"):
                fail(f"{name}: watch_folder is empty")
                continue
            if wf.exists():
                ok(f"{name}: watch folder exists: {wf}")
                waiting = [f for f in wf.iterdir() if f.is_file()]
                xls = [f for f in waiting if f.suffix.lower() == ".xls"]
                if xls:
                    warn(f"{name}: {len(xls)} old-format .xls file(s) will NOT be imported",
                         "Open in Excel and Save As .xlsx into the same folder")
                other = [f for f in waiting if f.suffix.lower() in (".xlsx", ".xlsm", ".csv")]
                if other:
                    warn(f"{name}: {len(other)} export(s) waiting to be imported",
                         "Start the logger; they import within ~10 seconds")
                failed = wf / "failed"
                if failed.exists() and any(failed.iterdir()):
                    warn(f"{name}: files in 'failed' folder could not be read",
                         "Check they are real Linshang exports; open them in Excel")
                imp = wf / "imported"
                if imp.exists():
                    n = sum(1 for _ in imp.iterdir())
                    ok(f"{name}: {n} file(s) already imported")
            else:
                warn(f"{name}: watch folder does not exist yet: {wf}",
                     "It is created when the logger starts, or create it yourself")
        else:
            warn(f"{name}: unknown type '{itype}'")
    return summary()


def summary():
    print("\n" + "=" * 64)
    fails = [r for r in RESULTS if r[0] == "FAIL"]
    warns = [r for r in RESULTS if r[0] == "WARN"]
    passes = [r for r in RESULTS if r[0] == "PASS"]
    print(f" RESULT: {len(passes)} passed, {len(warns)} warning(s), {len(fails)} problem(s)")
    if fails:
        print("\n Fix these first:")
        for _, m, f in fails:
            print(f"   - {m}" + (f"\n       {f}" if f else ""))
    elif not warns:
        print(" Everything looks good.")
    print("=" * 64)


if __name__ == "__main__":
    try:
        main()
    except KeyboardInterrupt:
        pass
    if sys.platform.startswith("win") and not sys.stdin.closed and sys.stdin.isatty():
        input("\nPress Enter to close...")
