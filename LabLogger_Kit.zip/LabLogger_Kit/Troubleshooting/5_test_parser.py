#!/usr/bin/env python3
"""
5_test_parser.py - Show exactly how the logger reads a printout.

Feed it a capture file from 4_capture_sample.py (or any text file with a
printout pasted in) and it shows each column the logger would fill in.
Empty columns are flagged so you can see what isn't being picked up.

Run:   python 5_test_parser.py                   choose a capture from a list
       python 5_test_parser.py captures/capture_pH_COM6_....txt --type ph
"""
import argparse
import importlib.util
import sys
from pathlib import Path

HERE = Path(__file__).resolve().parent


def load_logger():
    for c in (HERE.parent / "LabLogger", Path("C:/LabLogger"), Path.home() / "LabLogger",
              HERE.parent / "LabLogger_Backup", HERE):
        f = c / "lab_logger.py"
        if f.exists():
            spec = importlib.util.spec_from_file_location("lab_logger", f)
            mod = importlib.util.module_from_spec(spec)
            spec.loader.exec_module(mod)
            print(f"Using parser from {f}\n")
            return mod
    sys.exit("Could not find lab_logger.py (looked in C:\\LabLogger and the kit).")


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("file", nargs="?")
    ap.add_argument("--type", choices=["ph", "mb90"])
    a = ap.parse_args()
    L = load_logger()

    path = Path(a.file) if a.file else None
    if not path:
        caps = sorted((HERE / "captures").glob("capture_*.txt"))
        caps = [c for c in caps if not c.name.endswith(".hex.txt")]
        if not caps:
            sys.exit("No captures found. Run 4_capture_sample.py first, or pass a text file.")
        for i, c in enumerate(caps, 1):
            print(f"  {i}. {c.name}")
        n = input("Choose a file number: ").strip()
        path = caps[int(n) - 1] if n.isdigit() else Path(n)

    text = "\n".join(l for l in path.read_text(encoding="utf-8", errors="replace").splitlines()
                     if not l.startswith("# "))
    kind = a.type
    if not kind:
        kind = "mb90" if ("MB90" in text.upper() or "MOISTURE" in text.upper()) else "ph"
        print(f"Detected instrument type: {kind}  (override with --type ph or --type mb90)\n")

    if kind == "mb90":
        # MB90 printouts end with an END line; parse each separately
        chunks, cur = [], []
        for line in text.splitlines():
            cur.append(line)
            if L.SerialInstrument.END_MARKERS["mb90"].search(line):
                chunks.append("\n".join(cur))
                cur = []
        if any(l.strip() for l in cur):
            chunks.append("\n".join(cur))
        for i, ch in enumerate(chunks, 1):
            rec, curve = L.parse_mb90(ch)
            report(f"MB90 record {i}", rec)
            if curve:
                print(f"  Drying curve: {len(curve)} points, first {curve[0]}, last {curve[-1]}")
    else:
        start = L.SerialInstrument.START_MARKERS["ph"]
        chunks, cur = [], []
        for line in text.splitlines():
            if start.search(line) and any(l.strip() for l in cur):
                chunks.append("\n".join(cur))
                cur = []
            cur.append(line)
        if any(l.strip() for l in cur):
            chunks.append("\n".join(cur))
        for i, ch in enumerate(chunks, 1):
            print("Raw text:\n  " + "\n  ".join(ch.splitlines()))
            report(f"pH record {i}", L.parse_ph(ch))


def report(title, rec):
    print("=" * 60)
    print(f" {title}")
    print("=" * 60)
    empty = []
    for k, v in rec.items():
        if v in ("", None):
            empty.append(k)
        else:
            print(f"  {k:22s} {v}")
    if empty:
        print(f"\n  Not found in this printout: {', '.join(empty)}")
        print("  (Normal for fields that type of record doesn't contain. If a value you")
        print("   can see in the raw text is listed here, the parser needs adjusting.)")
    print()


if __name__ == "__main__":
    main()
    if sys.platform.startswith("win") and sys.stdin.isatty():
        input("\nPress Enter to close...")
