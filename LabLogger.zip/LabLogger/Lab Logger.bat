@echo off
rem Lab Logger launcher: starts the logger with no window and opens the dashboard.
rem If it can't start, this window stays open and says why.
cd /d "%~dp0"
title Lab Logger

if not exist "lab_logger.py" (
  echo.
  echo  Lab Logger can't find lab_logger.py in this folder:
  echo     %CD%
  echo.
  echo  Put "Lab Logger.bat" in the same folder as lab_logger.py, for example C:\LabLogger,
  echo  and make the desktop shortcut point to that copy.
  echo.
  pause
  exit /b
)

where python >nul 2>nul
if errorlevel 1 (
  echo.
  echo  Python isn't installed on this laptop, or wasn't added to PATH.
  echo  Reinstall Python from python.org and tick "Add python.exe to PATH".
  echo.
  pause
  exit /b
)

rem The program itself checks whether Lab Logger is already running:
rem same version -> it just opens the dashboard; older version -> it replaces it.

where pythonw >nul 2>nul
if errorlevel 1 (
  start "Lab Logger" /min python lab_logger.py
) else (
  start "" pythonw lab_logger.py
)

rem Wait up to 30 seconds for the dashboard to come up (replacing an older copy takes a moment).
timeout /t 3 /nobreak >nul
for /l %%i in (1,1,30) do (
  timeout /t 1 /nobreak >nul
  curl -s -o nul -m 2 http://localhost:8080 >nul 2>nul
  if not errorlevel 1 exit /b
)

echo.
echo  Lab Logger didn't start. Here is why:
echo  ------------------------------------------------------------
python lab_logger.py
echo  ------------------------------------------------------------
echo  The same message is saved in lab_logger.log in this folder.
echo.
pause
