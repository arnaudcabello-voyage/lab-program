LAB LOGGER - FILES
==================

Put everything in this folder into C:\LabLogger (replace the old files).

FILES
  lab_logger.py ................ the program
  lab_logger_config.json ....... settings: ports, folders, rules (see below)
  requirements.txt ............. list of parts the program needs
  Install Lab Logger parts.bat . run once on a new laptop (and after updates)
  Lab Logger.bat ............... starts Lab Logger and opens the dashboard
                                 (make the desktop shortcut from this one)
  Stop Lab Logger.bat .......... stops it (do this before replacing files)
  Lab Logger with window (troubleshooting).bat
                                 starts it with a window that shows messages
  demo_dashboard.bat ........... the dashboard with simulated instruments
                                 (saves nothing to the real data)

NOT IN THIS SET (made on the laptop, never replace or delete these)
  data\ ........................ all results, Excel workbooks, daily backups
  skala_token.txt .............. SKALA sign-in token (secret, this laptop only;
                                 easiest to set on the Support page)
  lab_logger.log ............... the logger's diary, useful for fault-finding

UPDATING
  1. Double-click Stop Lab Logger.bat
  2. Copy the new files into C:\LabLogger, replacing the old ones
  3. Double-click Install Lab Logger parts.bat (wait for "Done")
  4. Double-click Lab Logger

SKALA (AQUALAB 3) SIGN-IN
  Set up once: open the Support page, find "AQUALAB 3 - SKALA link", and drag
  the blue "Send to Lab Logger" button onto Chrome's bookmarks bar (Ctrl+Shift+B
  shows the bar). When SKALA needs reconnecting: open skalacontrol.io, sign in
  (pick your name, enter your PIN) so your batches show, then click "Send to Lab
  Logger". A tab opens saying "SKALA is connected".
  After updating lab_logger.py, delete the old bookmark and drag the button
  from the Support page again (the button itself can change between versions).

CLOUD COPY (automatic upload)
  Install and sign in to OneDrive (or Google Drive / Dropbox) on this laptop.
  Then on the Support page, under "Cloud copy", pick the folder Lab Logger
  finds and press "Save and copy now". From then on everything is copied there
  about a minute after it's saved, and the cloud app sends it online.

SETTINGS (lab_logger_config.json)
  Ports: MB90 = COM6, pH meter = COM3. If they change, fix them on the
  dashboard's Support page (bottom of the main page); no file editing needed.
  Everything saves under C:/LabLogger/data.
  Colorimeter exports go in C:/LabLogger/data/Colorimeter Exports
  (.xls, .xlsx and .csv are all fine).
  "lot_checklist": the tests every lot needs (Moisture, pH, Color, Water activity).
  pH meter "auto_save": true = readings save themselves (no need to tap print).
  Optional: "support_contact" (who operators should call), "support_pin"
  (a PIN for changing ports), "lot_rules" (lot format, operator name list,
  how long a lot stays active), "upload" (cloud folder), "void_rules"
  (how many minutes operators can void their own result without the PIN).

The old start_logger.bat is replaced by "Lab Logger with window
(troubleshooting).bat" and can be deleted.
