@echo off
rem For the supervisor: stops Lab Logger (e.g. before updating lab_logger.py).
curl -s -X POST -H "X-Lab-Logger: 1" -H "Content-Type: application/json" -d "{}" http://localhost:8080/api/shutdown >nul 2>nul
if %errorlevel%==0 (echo Lab Logger stopped.) else (echo Lab Logger was not running.)
timeout /t 3 >nul
