@echo off
cd /d "%~dp0"
title Lab Logger DEMO (simulated instruments)
python lab_logger.py --demo
pause
